'use strict'
module.exports = {
  NODE_ENV: '"production"',
  // API_HOST:'"http://ifbpmob.yonyou.com:8030/ifbpmob/"'
  API_HOST:'"http://10.15.0.189:1102/ifbpmob/"',
  //API_HOST:'"http://10.4.122.31:8130/ifbpmob/"'
}



