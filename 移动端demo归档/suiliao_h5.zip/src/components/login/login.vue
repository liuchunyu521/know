<template>
<div class="container">
    <div class="btn-login login-text">登录</div>
    <div class="btn-sign  login-text" @click="navtosign">注册</div>
    <div class="login-phone">
        <div class="num-add">+86</div>
        <input class="login-phonenum" v-model="tel" type="number" placeholder="请输入手机号">
    </div>
    <div class="login-psd">
        <input class="login-psd" v-model="psd" placeholder="请输入密码">
    </div>
    <div class="fogot-bar">
        <div class="choose-block" @click="changeAgreeState" :class="[tongyi?agreeicon:disagreeicon]"></div>
        <div class="agree">同意随聊《<span class="xieyi" @click="openXieyi">用户注册协议</span>》</div>
        <div class="fogot-btn">忘记密码</div>
    </div>
    <button class="login-btn" @click="login" :class="[isready=='yes'?canlogin:cannotlogin]">完成</button>  
</div>

</template>
<script>
// import "../styles/vacationapply.css";
import { MessageBox } from 'mint-ui';
import { DatetimePicker } from 'mint-ui';
import { Toast } from 'mint-ui';
import { Indicator } from 'mint-ui';
import { Actionsheet } from 'mint-ui';
import axios from 'axios';
export default {
  name: "login",
  data() {
    return{
      canlogin:"can-login",
      cannotlogin:"cannot-login",
      tel:"",
      psd:"",
      isready:"no",
      tongyi:true,
      agreeicon:"agreeicon",
      disagreeicon:"disagreeicon"
    }
  },
  watch:{
      tel(val){
          if(this.tel!=""&&this.psd!=""&&this.tongyi==true){
              this.isready="yes"
          }
          else{
               this.isready="no"
               console.log("no")
               console.log(this.tel+"---"+this.psd+"---"+this.tongyi)
          }
      },
      psd(val){
        if(this.tel!=""&&this.psd!=""&&this.tongyi==true){
            this.isready="yes"
        }
        else{
            this.isready="no"
        }
      },
      tongyi(val){
        if(this.tel!=""&&this.psd!=""&&this.tongyi==true){
            this.isready="yes"
        }
        else{
            this.isready="no"
        }
      }
  },
  created(){
   
  },
  mounted(){
      //   腾讯im登陆
    let loginInfo = {};
    loginInfo.sdkAppID = "1400068060";
    loginInfo.appIDAt3rd = "1400068060";
    loginInfo.identifier = "8447633";
    loginInfo.identifierNick = "ly";
    loginInfo.userSig = "eJxFkF1PgzAUhv8LtxrXlraAyS6wuGTiovuIRm*aBg5LdUIpHYJm-13EEW*fJyfv*55vb3e-vVLG6FwqJ32be9ce8i5HDJ3RFqQqHNgBY8YYQWiyLdhGV*UgCMIMEx*hf6lzKJ0u9HgYUhpw3z*rRu8Htrpdi6VgmjagAKFWFQHMaqhTArTdPtbBDbiXNFoskg1perGOddxfJB3b4Ifd0cbPX-hQoOVhnz0JMUsTHPLVXecMq5JX8vY5n09h*bsc1-32p0M-HiI*lXT6A-52cYojRqMzV1lWHUsnXW9gfMfpBw*aVkI_";
    loginInfo.accountType = 1

    let listeners = {
        "onConnNotify": onConnNotify//监听连接状态回调变化事件,必填
        ,"jsonpCallback": jsonpCallback//IE9(含)以下浏览器用到的 jsonp 回调函数，
        ,"onMsgNotify": onMsgNotify//监听新消息(私聊，普通群(非直播聊天室)消息，全员推送消息)事件，必填
        // ,"onBigGroupMsgNotify": onBigGroupMsgNotify//监听新消息(直播聊天室)事件，直播场景下必填
        // ,"onGroupSystemNotifys": onGroupSystemNotifys//监听（多终端同步）群系统消息事件，如果不需要监听，可不填
        // ,"onGroupInfoChangeNotify": onGroupInfoChangeNotify//监听群资料变化事件，选填
        // ,"onFriendSystemNotifys": onFriendSystemNotifys//监听好友系统通知事件，选填
        // ,"onProfileSystemNotifys": onProfileSystemNotifys//监听资料系统（自己或好友）通知事件，选填
        // ,"onKickedEventCall" : onKickedEventCall//被其他登录实例踢下线
        // ,"onC2cEventNotifys": onC2cEventNotifys//监听 C2C 系统消息通道
    };
    var onConnNotify = function (resp) {
    var info;
    switch (resp.ErrorCode) {
        case webim.CONNECTION_STATUS.ON:
            webim.Log.warn('建立连接成功: ' + resp.ErrorInfo);
            break;
        case webim.CONNECTION_STATUS.OFF:
            info = '连接已断开，无法收到新消息，请检查下您的网络是否正常: ' + resp.ErrorInfo;
            alert(info);
            webim.Log.warn(info);
            break;
        case webim.CONNECTION_STATUS.RECONNECT:
            info = '连接状态恢复正常: ' + resp.ErrorInfo;
            alert(info);
            webim.Log.warn(info);
            break;
        default:
            webim.Log.error('未知连接状态: =' + resp.ErrorInfo);
            break;
        }
    };
    function jsonpCallback(rspData) {
    //设置 jsonp 返回的
        webim.setJsonpLastRspData(rspData);
    }
    //监听新消息事件
//newMsgList 为新消息数组，结构为[Msg]
    function onMsgNotify(newMsgList) {
        //console.warn(newMsgList);
        var sess, newMsg;
        //获取所有聊天会话
        var sessMap = webim.MsgStore.sessMap();
        for (var j in newMsgList) {//遍历新消息
            newMsg = newMsgList[j];
            if (newMsg.getSession().id() == selToID) {//为当前聊天对象的消息
                selSess = newMsg.getSession();
                //在聊天窗体中新增一条消息
                //console.warn(newMsg);
                addMsg(newMsg);
            }
        }
        //消息已读上报，以及设置会话自动已读标记
        webim.setAutoRead(selSess, true, true);
        for (var i in sessMap) {
            sess = sessMap[i];
            if (selToID != sess.id()) {//更新其他聊天对象的未读消息数
                updateSessDiv(sess.type(), sess.id(), sess.unread());
            }
        }
    }         
    let opts = {
        isAccessFormalEnv:true,
        isLogOn:false
    }   
    let cbOk = function(resp){
        loginInfo.identifierNick = resp.identifierNick;//设置当前用户昵称
        console.log(resp)
        console.log("im 登录成功")
    }
    let cbErr = function(err){
        alert(err.ErrorInfo);
    }
    setTimeout(function(){
        webim.login(loginInfo, listeners,opts,cbOk,cbErr);
    },100)

 
     
  },
  methods: {
    openXieyi(){
        window.location.href = "http://isuiliao.cn/privacy.html";
    },
    changeAgreeState(){
        this.tongyi = !this.tongyi;
    },
    login(){
        if(this.isready=="no"){
            return false;
        }else{
             this.callService({
              hash:"/suiliao-api/suiliao/sys/login",
              params:{
                phone:this.tel,
                password:this.psd,
                third_type:4,
              },
              success:(res)=>{
                console.log(res)
                if(res.err_code=="8888"){
                    debugger
                    localStorage.setItem("userInfo",JSON.stringify(res.result))
                  this.$router.push({name:"homepage", params: {}})
                }else{
                  Toast(res.err_msg)
                }
              },
              fail:function(){

              }
            }); 
        }
    },
    navtosign(){
        this.$router.push({name:"sign", params: {}})
    }
  }

};
</script>
<style  scoped lang="scss">
*{
    margin:0;
    padding:0;
}
$pink:#FF8586;
.agreeicon{
    background:url("../../assets/suiliao/zc-tyix@2x.png") no-repeat center;
    background-size:14px;
}
.disagreeicon{
    background:url("../../assets/suiliao/zc-tyi@2x.png") no-repeat center;
    background-size:14px;
}
.login-btn{
    width:90%;
    margin:0 auto;
    height:42px;
    line-height:42px;
    font-size:14px;
    display: block;
    border:none;
    margin-top:30px;
    outline: none;
}
.can-login{
    background:$pink;
    color:#fff;
}
.cannot-login{
    background:#eee;
    color:#fff;
}
.fogot-bar{
    height:20px;
    display:flex;
    font-size:12px;
    width:90%;
    margin:0 auto;
    .choose-block{
        width:20px;
        height:20px;
        margin-top:-1px;
        margin-right:3px;
    }
    .agree{
        color:#999;
        font-size:12px;
        flex:1;
        span{
            color:$pink;
        }
    }
    .fogot-btn{
        color:$pink;
    }
}
.container{
    width:100vw;
    height:100vh;
    background:#fff;
    position: absolute;
    z-index:9999;
    overflow: hidden;
}
.login-text{
    font-size:20px;
    font-weight: bold;
    padding-left:20px;
    height:20px;
    line-height:20px;
}
.login-phone{
    width:90%;
    margin:30px auto 20px auto;
    border-bottom: 1px solid #E3E3E3;
    display:flex;
    height:40px;
    font-size:14px;
    .num-add{
        width:40px;
        line-height: 40px;
    }
    .login-phonenum{
        outline: none;
        flex:1;
        line-height:40px;
        font-size:14px;
        border:none;
    }
}
.login-psd{
    width:90%;
    margin:0 auto 20px auto;
    border-bottom: 1px solid #E3E3E3;
    display:flex;
    height:40px;
    font-size:14px;
    display:flex;
    .login-psd{
        outline: none;
        flex:1;
        line-height:40px;
        font-size:14px;
        border:none;
        height:38px;
    }
}
.btn-login{
    padding-top:50px;
}
.btn-sign{
    font-weight: 100;
    padding-top:20px;
}
.clear{
  clear:both;
}

</style>