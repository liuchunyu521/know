<template>
  <div class="container topscroll" >
     <public-header :title="'信息'"></public-header>
    <div class="msglist-con">
        <div class="msg-list" v-for="(item,index) in 10" :key="index">
            <div class="header-con"></div>
            <div class="main-con">
                <div class="main-left">
                    <div class="name">一条小咸鱼</div>
                    <div class="msg">你好，今天有空吗</div>
                </div>
                <div class="main-right">
                    <div class="tip">1</div>
                    <div class="time">10:36</div>
                </div>
            </div>
        </div>
    </div>
     
  </div>
</template>
<script>
// import "../styles/vacationlist.css";
import { Loadmore } from 'mint-ui';
import { Toast } from 'mint-ui';
import { Indicator } from 'mint-ui';
import axios from 'axios';
import PublicHeader from '@/components/public_components/header'
export default {
  name: "message",
  components:{PublicHeader},
  data() {
    return {
        userInfo:{},
        accountInfo:{},
        levelInfo:{},
        uid:"",
        footer:false,
        userInfo_mine:{},
        isFocus:0,
        focusText:"关注",
        maleIcon:"maleIcon",
        femaleIcon:"femaleIcon",


    };
  },
  methods: {
      focus(){
            this.callService({
                hash:"/suiliao-api/suiliao/user/addFollow",
                params:{
                    uid:this.userInfo_mine.uid,
                    touid:this.userInfo.uid
                },
                success:(res)=>{
                console.log(res)
                if(res.err_code=="8888"){
                    this.isFocus = 1;
                    this.focusText = "已关注";
                }else{
                    Toast(res.err_msg)
                }
                },
                fail:function(){

                }   
            });  
      },
      getSelectData(res){
        this.leaveKind = res.selected;
      },
      getSelectData2(res){
        this.leaveAim = res.selected;
      },
      returnFun(){
        console.log(22)
      }
  },
  created: function() {
  },
  mounted:function(){
      $(".goback-btn").hide();
      $(".corner-fun").hide();
      this.userInfo_mine = JSON.parse(localStorage.getItem("userInfo"));
      console.log(this.userInfo_mine)
       this.uid = this.$route.params.uid;
       this.callService({
        hash:"/suiliao-api/suiliao/user/getUserInfo",
        params:{
          uid:this.uid,
          channel:"suiliao"
        },
        success:(res)=>{
          console.log(res)
          if(res.err_code=="8888"){
             
               
          }else{
           
          }
        },
        fail:function(){

        }
      }); 
    //   是否关注 	/suiliao-api/suiliao/user/checkFollow

   
  }
};

</script>
<style scoped lang="scss"> 
    .container{
        margin-top:45px;
        margin-bottom:45px;
    }
    .msg-list{
        height:60px;
        display: flex;
        .header-con{
            width:60px;
            height:60px;
        }
        .main-con{
            flex:1;
            display: flex;
            border-bottom:1px solid #e1e1e1;
            .main-left{
                flex:1;
                .name{
                    color:#333;
                    font-size:17px;
                    height:17px;
                    padding:10px 0 6px 0;
                }
                .msg{
                    color:rgb(144,144,144);
                    font-size:14px;
                    height:14px;
                }
            }
            .main-right{
                width:60px;
                height:60px;
                .tip{
                    color:#fff;
                    width:12px;
                    height:12px;
                    font-size:12px;
                    text-align: center;
                    line-height:12px;
                    background:red;
                    border-radius:50%;
                    margin:12px auto 6px auto;
                }
                .time{
                    color:rgb(144,144,144);
                    font-size:14px;
                    height:14px;
                    text-align:center;
                }
            }
        }
    }
</style>



