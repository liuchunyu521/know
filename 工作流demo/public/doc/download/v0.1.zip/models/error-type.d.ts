export declare enum ErrorType {
    Ok = 0,
    Error = 1
}
