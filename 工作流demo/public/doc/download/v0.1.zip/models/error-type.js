export var ErrorType;
(function (ErrorType) {
    ErrorType[ErrorType["Ok"] = 0] = "Ok";
    ErrorType[ErrorType["Error"] = 1] = "Error";
})(ErrorType || (ErrorType = {}));
