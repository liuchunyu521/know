import WorkflowApprove from './workflow-approve';
import WorkflowReject from './workflow-reject';
import { reject, canTaskRevoke, revoke, startWorkflow } from './workflow-func';
export { WorkflowApprove, WorkflowReject };
export { reject, canTaskRevoke, revoke, startWorkflow };
declare function install(vue: any, opt: any): void;
declare const _default: {
    install: typeof install;
};
export default _default;
